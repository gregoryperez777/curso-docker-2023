

export const types = {
    login:  '[Auth] Login',
    logout: '[Auth] Logout',
}

